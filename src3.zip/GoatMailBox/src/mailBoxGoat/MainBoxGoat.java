package mailBoxGoat;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import control.LoginManagement;
import control.MailControl;
import tools.Chronometer;
import tools.DateCreation;
import tools.InstantCreation;
import view.interfaceFX.WindowsFX;
import view.messages.CodeReturnMail;

public class MainBoxGoat {
	private static MailControl control;
	private static String loginID, loginPW;
	private static Logger log = LogManager.getLogger();
	private static List<Integer> returnCodes;

	public static void main(String[] args) {
		Chronometer chronometer;
		DateCreation date;
		InstantCreation instant;
		CodeReturnMail codeManagement;
		WindowsFX windowsFX;

		// Initialization
		returnCodes = new ArrayList<Integer>();
		loginID = new String();
		loginPW = new String();
		instant = new InstantCreation();
		date = new DateCreation();
		chronometer = new Chronometer();
		windowsFX = new WindowsFX();

		// Time & date management
		addReturnCode(chronometer.startTime());
		addReturnCode(instant.getReturnCode());
		addReturnCode(date.getReturnCode());

		log.info("*******************************************************");
		log.info("MailGoat opened " + date.getDDMMAAAAToday() + " at " + instant.getDayTime());

		// Launching the interface
		windowsFX.launchwindows(args);

		// Results of the time passed
		addReturnCode(chronometer.stopTime());
		log.info("MailGoat was open durring " + chronometer.getPassedTime() + " ms");

		// Return codes management
		codeManagement = new CodeReturnMail(returnCodes, log);
		codeManagement.codesTranslation();
	}

	/**
	 * 
	 * @param adressee
	 * @param object
	 * @param message
	 * @param Password
	 * @param ID
	 */
	public static void writeMessage(String addressee, String object, String message) {
		control = MailControl.instance(log, addressee, object, message, loginID, loginPW);
		control.writingMail();
		control.sendMail();
	}

	/**
	 * 
	 * @param code
	 */
	public static void addReturnCode(int code) {
		returnCodes.add(code);
	}

	/**
	 * 
	 * @param addressee
	 * @param object
	 * @param message
	 */
	public static void writeDraft(String addressee, String object, String message) {
		control = MailControl.instance(log, addressee, object, message, loginID, loginPW);
		control.writingMail();

	}

	/**
	 * 
	 * @param id
	 * @param pw
	 */
	public static boolean gatheredLogin(String id, String pw) {
		boolean sameLogin;

		sameLogin = false;

		if (LoginManagement.isLogin(id)) {
			if (LoginManagement.isPassword(pw)) {
				// Good logins
				sameLogin = true;
				loginID = id;
				loginPW = pw;
			}
		}

		return sameLogin;
	}

}// END PROGRAM
