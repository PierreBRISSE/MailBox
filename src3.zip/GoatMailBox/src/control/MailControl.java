package control;

import java.io.File;

import org.apache.logging.log4j.Logger;

import model.ModelSocketCreation;
import tools.Writing;

public class MailControl extends AbstractMailControl implements Repertory {
	private static MailControl instanceControl = null;
	private static final String separator = "###";

	private MailControl(Logger log, String addressee, String object, String message, String loginID, String loginPW) {
		super();
		super.setReturnCode(100);
		super.setLog(log);
		super.setId(loginID);
		super.setPassword(loginPW);
		super.setAdressee(addressee);
		super.setObject(object);
		super.setMessage(message);
		super.setContent(super.adressee + separator + super.object + separator + super.message + separator + super.id
				+ separator + super.password);
		super.setFile(new File(pathDraft));
	}

	/**
	 * 
	 * @param log
	 * @param adressee
	 * @param object
	 * @param message
	 * @param loginPW
	 * @param loginID
	 * @return instance Control
	 */
	public static MailControl instance(Logger log, String addressee, String object, String message, String loginID,
			String loginPW) {
		if (instanceControl == null) {
			instanceControl = new MailControl(log, addressee, object, message, loginID, loginPW);
		}

		return instanceControl;
	}

	/**
	 * Write the content of the mail in a file to save it temporally
	 * 
	 * @return returnCode
	 */
	public int writingMail() {
		Writing writing;

		super.log.trace("MailGoat - " + MailControl.class + " writing the mail into draft.");

		writing = new Writing(super.log, super.file, super.content);
		writing.writingFile();
		super.returnCode = writing.writingFile();

		return super.returnCode;
	}

	/**
	 * 
	 * @return returnCode
	 */
	public int sendMail() {
		super.log.trace("MailGoat - " + MailControl.class + " send mail.");

		super.socketCreation = ModelSocketCreation.instanceSocketCreation(pathDraft, port, adress, super.content, log);
		super.returnCode = super.socketCreation.getReturnCode();

		if (super.returnCode > 99) {
			super.socketCreation.start();
			super.returnCode = super.socketCreation.getReturnCode();
		}

		return super.returnCode;
	}

}// END PRG
