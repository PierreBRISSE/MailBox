package model;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.net.SocketException;

import org.apache.logging.log4j.Logger;

public class ModelSocketCreation extends ModelAbstractSocketCreation {
	private static ModelSocketCreation instanceSocketCreation = null;

	private ModelSocketCreation(String path, int port, String adress, String content, Logger log) {
		super();
		super.setReturnCode(100);
		super.setLog(log);
		super.setPath(path);
		super.setAdress(adress);
		super.setPort(port);
		super.setContent(content);
	}

	/**
	 * 
	 * @param path
	 * @param port
	 * @param adress
	 * @param id
	 * @param message
	 * @param logger
	 * @return SocketCreation or null
	 */
	public static ModelSocketCreation instanceSocketCreation(String path, int port, String adr, String ct, Logger log) {
		if (instanceSocketCreation == null) {
			instanceSocketCreation = new ModelSocketCreation(path, port, adr, ct, log);
		}

		return instanceSocketCreation;
	}

	/**
	 * 
	 * @return returnCode
	 */
	public int start() {

		try {
			super.log.trace("MailGoat -" + ModelSocketCreation.class + " starting the connection.");
			super.socket = new Socket(super.adress, super.port);

			message();
			read();

			close();

		} catch (SocketException e) {
			super.returnCode = 15;
		} catch (Exception e) {
			super.returnCode = 11;
		}

		return super.returnCode;
	}

	private void close() {
		try {
			super.socket.close();

		} catch (IOException e) {
			super.returnCode = 13;
		}
	}// -

	/**
	 * Read the flux
	 */
	private void read() {

		try (DataInputStream reading = new DataInputStream(super.socket.getInputStream())) {
			super.log.trace("MailGoat - " + ModelSocketCreation.class + " reading a stream");

			while (reading.available() > 0) {
				super.in += reading.readUTF();
			}

			reading.close();

		} catch (IOException e) {
			super.returnCode = 12;
		} catch (Exception e) {
			super.returnCode = 14;
		}

	}// -

	/**
	 * Send a message
	 */
	private void message() {
		DataOutputStream dataOutputStream;

		dataOutputStream = null;

		try {
			super.log.trace("MailGoat -" + ModelSocketCreation.class + " writing the message");

			dataOutputStream = new DataOutputStream(super.socket.getOutputStream());
			dataOutputStream.writeUTF(super.content);

			dataOutputStream.close();

		} catch (IOException e) {
			super.returnCode = 17;
		} catch (Exception e) {
			super.returnCode = 18;
		}
	}

}// END PRG
