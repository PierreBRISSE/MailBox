package view.interfaceFX;

import java.io.IOException;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import mailBoxGoat.MainBoxGoat;

public class IdPwPage {

	@FXML
	private TextField textID;

	@FXML
	private Label labelInfo;

	@FXML
	private TextField textPW;

	@FXML
	private Button valideButton;

	@FXML
	private Button closeButton;

	public Scene getScene() throws IOException {
		Parent root;
		Scene scene;

		root = FXMLLoader.load(getClass().getResource("IdPage.fxml"));
		scene = new Scene(root);

		return scene;
	}

	@FXML
	void exitIDPW(ActionEvent event) {
		Platform.exit();
	}

	@FXML
	void valideIDPW(ActionEvent event) throws Exception {
		WelcomePage welcomePage;
		Scene scene2;
		Stage window2;
		String id, pw;
		boolean goodLogins;

		id = textID.getText();
		pw = textPW.getText();
		goodLogins = false;

		if (id.isBlank() == false) {
			if (pw.isBlank() == false) {
				// Checking if the logins are the good logins
				goodLogins = MainBoxGoat.gatheredLogin(id, pw);
				if (goodLogins == true) {
					// Switching to the welcome page
					welcomePage = new WelcomePage();
					scene2 = welcomePage.getScene();
					window2 = (Stage) ((Node) event.getSource()).getScene().getWindow();
					window2.setScene(scene2);
					window2.show();

				} else {
					labelInfo.setText("Wrong logins !");
				}

			} else {
				labelInfo.setText("Empty password !");
			}
		} else {
			labelInfo.setText("Empty ID !");
		}
	}

}// END PRG
