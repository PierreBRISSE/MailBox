package control;

import org.apache.logging.log4j.Logger;
import org.hibernate.Session;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import model.ModelLoginBase;

public class ControlSql extends AbstractControlSQL {
	private static ControlSql instanceControlSql = null;

	private ControlSql(Logger logger) {
		super();
		super.setReturnCode(100);
		super.setLogger(logger);
	}

	public static ControlSql instance(Logger logger) {
		if (instanceControlSql == null) {
			instanceControlSql = new ControlSql(logger);
		}

		return instanceControlSql;
	}

	// SQL methods
	/**
	 * 
	 * @param id
	 * @param password
	 * @return returnCode
	 */
	public int find(String id, String password) {
		String idFound, passwordFound;
		List<ModelLoginBase> found;
		boolean sames;

		super.logger.trace("Sever - SQL request find for " + id);

		try (Session sessionCreation = SessionCreation.getSessionFactory().openSession()) {
			super.logger.trace("communication with MySQL");

			CriteriaBuilder builder = sessionCreation.getCriteriaBuilder();
			CriteriaQuery<ModelLoginBase> criteriaQuery = builder.createQuery(ModelLoginBase.class);
			Root<ModelLoginBase> root = criteriaQuery.from(ModelLoginBase.class);
			criteriaQuery.select(root);

			// Condition creation
			Predicate p = builder.equal(root.<String>get("loginID"), builder.parameter(String.class, "loginID"));
			criteriaQuery.where(p);

			// Collecting the results
			found = sessionCreation.createQuery(criteriaQuery).setParameter("loginID", id).getResultList();

			// Checking if the logins correspond
			sames = false;
			for (ModelLoginBase modelLoginBase : found) {
				idFound = modelLoginBase.getLoginID();
				passwordFound = modelLoginBase.getLoginPassword();

				if (idFound.equals(id) & passwordFound.equals(password)) {
					sames = true;
				}
			}

			// Did we found the good logins ?
			if (sames == false) {
				super.returnCode = 75;
			}

		} catch (Exception e) {
			super.returnCode = 70;
		}

		return this.returnCode;
	}

}// END PRG
