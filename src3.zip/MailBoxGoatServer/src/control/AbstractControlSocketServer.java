package control;

import java.net.InetAddress;
import java.util.List;

import org.apache.logging.log4j.Logger;

import model.ModelServerSocket;

public abstract class AbstractControlSocketServer {
	protected InetAddress url;
	protected ModelServerSocket modelServerSocket;
	protected Logger log;
	protected List<Integer> returnCode;

	// Getters & Setters :
	protected void setReturnCode(List<Integer> returnCode) {
		this.returnCode = returnCode;
	}

	public Logger getLogger() {
		return log;
	}

	protected void setLogger(Logger logger) {
		this.log = logger;
	}

	/**
	 * 
	 * @param code
	 */
	protected void addReturnCode(int code) {
		this.returnCode.add(code);
	}

}// END PRG
