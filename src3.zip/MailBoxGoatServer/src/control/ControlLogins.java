package control;

import java.util.ArrayList;

import org.apache.logging.log4j.Logger;

public class ControlLogins extends AbstractControlLogins {
	private static ControlLogins instanceControlLogins = null;

	private ControlLogins(ArrayList<String> logins, Logger logger) {
		super();
		super.setReturnCode(100);
		super.setLogger(logger);
		super.setId(logins.get(0));
		super.setPassword(logins.get(1));
	}

	public static ControlLogins instance(ArrayList<String> logins, Logger logger) {
		if (instanceControlLogins == null) {
			instanceControlLogins = new ControlLogins(logins, logger);
		}

		return instanceControlLogins;
	}

	// Check methods
	/**
	 * 
	 * @return returnCode
	 */
	public int isLoginCorrect() {
		ControlSql sql;

		if (super.id.isBlank() == false & super.password.isBlank() == false) {
			super.logger.trace("Sever - " + ControlLogins.class);
			sql = ControlSql.instance(super.logger);

			super.returnCode = sql.find(super.id, super.password);
			
		} else {
			super.returnCode = 65;
		}

		return super.returnCode;
	}

}// END PRG
