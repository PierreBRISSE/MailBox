package control;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.Logger;

import model.ModelServerSocket;

public class ControlSocketServer extends AbstractControlSocketServer implements Repertory {
	private static ControlSocketServer instanceContolServerSocket = null;

	private ControlSocketServer(Logger logger) {
		super();
		super.setReturnCode(new ArrayList<Integer>());
		super.addReturnCode(100);
		super.setLogger(logger);
	}

	/**
	 * 
	 * @param logger
	 * @return new ContolServerSocket or null
	 */
	public static ControlSocketServer getInstanceContolServerSocket(Logger logger) {
		if (instanceContolServerSocket == null) {
			instanceContolServerSocket = new ControlSocketServer(logger);
		}

		return instanceContolServerSocket;
	}

	/**
	 * Opening the server
	 * 
	 * @param logger
	 * 
	 * @return returnCode
	 */
	public List<Integer> openServer() {
		super.log.trace("Sever - " + ControlSocketServer.class);

		try {

			super.url = InetAddress.getLocalHost();
			super.modelServerSocket = ModelServerSocket.getInstanceModelServerSocket(port, super.url, path, log,
					timeout);

			if (super.url.toString().isBlank() == false) {
				super.modelServerSocket.start();
				// Gathering the return codes from modelServerSocket
				for (int returnCodeModel : super.modelServerSocket.getReturnCode()) {
					super.addReturnCode(returnCodeModel);
				}

			} else {
				super.addReturnCode(31);
			}

		} catch (UnknownHostException e) {
			super.addReturnCode(35);
		} catch (Exception e) {
			super.addReturnCode(36);
		}

		return super.returnCode;
	}// -

}// END PRG
