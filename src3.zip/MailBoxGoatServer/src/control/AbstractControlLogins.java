package control;

import org.apache.logging.log4j.Logger;

public abstract class AbstractControlLogins {
	protected String id, password;
	protected Logger logger;
	protected int returnCode;

	// Getters & Setters
	public String getId() {
		return id;
	}

	protected void setId(String id) {
		this.id = id;
	}

	public String getPassword() {
		return password;
	}

	protected void setPassword(String password) {
		this.password = password;
	}

	public Logger getLogger() {
		return logger;
	}

	public void setLogger(Logger logger) {
		this.logger = logger;
	}

	public int getReturnCode() {
		return returnCode;
	}

	public void setReturnCode(int returnCode) {
		this.returnCode = returnCode;
	}

}// END PRG
