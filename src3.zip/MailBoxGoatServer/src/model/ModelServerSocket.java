package model;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.Logger;

import control.ControlLogins;
import tools.Writing;

public class ModelServerSocket extends AbstractModelSocketServer {
	private static ModelServerSocket instanceModelServerSocket = null;

	private ModelServerSocket(int port, InetAddress url, String path, Logger logger, int timeout) {
		super();
		super.setReturnCode(new ArrayList<Integer>());
		super.addReturnCode(100);
		super.setErrorReturnCode(false);
		super.setPort(port);
		super.setUrl(url);
		super.setPath(path);
		super.setStayAlive(true);
		super.setTime(timeout);
		super.setLogger(logger);
	}

	/**
	 * 
	 * @param port
	 * @param url
	 * @param path
	 * @param logger
	 * @param timeout
	 * @return ModelServerSocket
	 */
	public static ModelServerSocket getInstanceModelServerSocket(int p, InetAddress url, String path, Logger l, int t) {
		if (instanceModelServerSocket == null) {
			instanceModelServerSocket = new ModelServerSocket(p, url, path, l, t);
		}

		return instanceModelServerSocket;
	}

	/**
	 * Close the socket
	 * 
	 * @return returnCode
	 */
	private void close() {
		super.logger.trace("Sever - " + ModelServerSocket.class + " close");

		try {
			super.socket.close();

		} catch (Exception e) {
			super.addReturnCode(13);
		}

	}

	/**
	 * Start the connection
	 * 
	 * @param logger
	 * 
	 * @return returnCode;
	 */
	public void start() {

		try (ServerSocket serverSocket = new ServerSocket(super.port);) {
			super.logger.trace("Sever - " + ModelServerSocket.class + " start at port : " + super.port);
			super.logger.trace(" for a duration of " + super.time / 1000 + " s");

			serverSocket.setSoTimeout(super.time);
			super.socket = serverSocket.accept();

			read(); // Entrance flux
			if (super.errorReturnCode == false) {
				super.logger.trace("Sever - Starting to save the mail in a file ");
				messageSave();
//				message();

			} else {
				super.stayAlive = false;
			}

			if (super.stayAlive == true) {
				close();
				serverSocket.close();
			}

		} catch (SocketTimeoutException e) {
			super.addReturnCode(101);
		} catch (SocketException e) {
			super.addReturnCode(15);
		} catch (Exception e) {
			super.addReturnCode(11);
		}

	}

	/**
	 * Writing the content of the mail in a file
	 */
	private void messageSave() {
		ControlLogins controlLogins;
		Writing writer;
		ArrayList<String> logins;
		String separator;

		super.logger.trace("Sever - Proccessing the checking steps before writing the mail ");

		writer = new Writing(super.in);
		logins = new ArrayList<String>();
		separator = "###";

		// Gather the id and password
		logins = writer.getLogins(separator);
		if (logins.isEmpty() == true) {
			System.out.println("no login");//TODO
			super.addReturnCode(65);

		} else {
			// Check if it exists in the database
			super.logger.trace("Sever - starting to ckeck the logins ");
			controlLogins = ControlLogins.instance(logins, super.logger);
			super.addReturnCode(controlLogins.isLoginCorrect());

			// If the logins exits, then the mail can be saved
			if (super.errorReturnCode == false) {
				super.logger.trace("Sever - Starting to write the flux");
				super.addReturnCode(writer.writingMail(separator, super.path));
			}

		}

		super.in = null;
	}

	/**
	 * Collect the stream
	 */
	private void read() {

		try (DataInputStream reading = new DataInputStream(super.socket.getInputStream())) {
			super.logger.trace("Sever - " + ModelServerSocket.class + " reading a stream");

			while (reading.available() > 0) {
				super.in += reading.readUTF();
			}

			reading.close();

		} catch (IOException e) {
			super.addReturnCode(12);
		} catch (Exception e) {
			super.addReturnCode(14);
		}

	}// -

	/**
	 * Send a message
	 */
	private void message() {

		try (DataOutputStream dataOutputStream = new DataOutputStream(super.socket.getOutputStream())) {
			super.logger.trace("Sever -" + ModelServerSocket.class + " writing the return message");

			dataOutputStream.writeUTF("confirm");
			dataOutputStream.flush();

			dataOutputStream.close();

		} catch (IOException e) {
			super.addReturnCode(17);
		} catch (Exception e) {
			super.addReturnCode(18);
		}
	}

	/**
	 * Method to use if you want to find a port
	 */
//	public void portAction() {
//		ServerSocket serverSocketPort;
//
//		for (int portTest = 1; portTest <= 65535; portTest++) {
//			try {
//				serverSocketPort = new ServerSocket(portTest);
//			} catch (IOException e) {
//				System.err.println("Le port " + portTest + " est d�j� utilis� ! ");
//			}
//		}
//	} // -

}// END PRG